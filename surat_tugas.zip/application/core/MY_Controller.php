<?php defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller {

    

}
require_once(APPPATH.'/core/Admin_Controller.php');
require_once(APPPATH.'/core/Public_Controller.php');
require_once(APPPATH.'/core/Mobile_Controller.php');
/* End of file MY_Controller.php */
