<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Public_Controller extends MY_Controller {

    function __construct(){
        parent::__construct();
    }

    public function index()
    {
        
    }

}

/* End of file Public_Controller.php */
