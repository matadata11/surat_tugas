<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-11-23 03:49:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-11-23 03:49:30 --> Severity: error --> Exception: syntax error, unexpected '<<' (T_SL), expecting end of file C:\xampp\htdocs\surat_tugas\application\config\routes.php 19
ERROR - 2022-11-23 03:50:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-11-23 09:50:15 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) C:\xampp\htdocs\surat_tugas\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2022-11-23 09:50:15 --> Unable to connect to the database
ERROR - 2022-11-23 03:50:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-11-23 03:50:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-11-23 09:50:50 --> Severity: Warning --> include_once(C:\xampp\htdocs\surat_tugas\application\../vendor/autoload.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 8
ERROR - 2022-11-23 09:50:50 --> Severity: Warning --> include_once(): Failed opening 'C:\xampp\htdocs\surat_tugas\application\../vendor/autoload.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 8
ERROR - 2022-11-23 09:50:50 --> Severity: error --> Exception: Class 'Google_Client' not found C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 9
ERROR - 2022-11-23 03:51:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-11-23 04:01:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-11-23 04:01:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-11-23 04:01:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-11-23 04:01:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-11-23 10:01:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:01:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 04:01:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-11-23 10:01:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 04:01:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-11-23 04:01:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-11-23 10:01:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:01:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 04:01:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-11-23 04:01:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-11-23 10:01:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:01:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 04:02:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-11-23 04:02:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-11-23 10:02:56 --> Severity: Warning --> include_once(C:\xampp\htdocs\surat_tugas\application\../vendor/autoload.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 8
ERROR - 2022-11-23 10:02:56 --> Severity: Warning --> include_once(): Failed opening 'C:\xampp\htdocs\surat_tugas\application\../vendor/autoload.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 8
ERROR - 2022-11-23 10:02:56 --> Severity: error --> Exception: Class 'Google_Client' not found C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 9
ERROR - 2022-11-23 04:02:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-11-23 10:02:59 --> Severity: Warning --> include_once(C:\xampp\htdocs\surat_tugas\application\../vendor/autoload.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 8
ERROR - 2022-11-23 10:02:59 --> Severity: Warning --> include_once(): Failed opening 'C:\xampp\htdocs\surat_tugas\application\../vendor/autoload.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 8
ERROR - 2022-11-23 10:02:59 --> Severity: error --> Exception: Class 'Google_Client' not found C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 9
ERROR - 2022-11-23 04:03:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-11-23 10:03:00 --> Severity: Warning --> include_once(C:\xampp\htdocs\surat_tugas\application\../vendor/autoload.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 8
ERROR - 2022-11-23 10:03:00 --> Severity: Warning --> include_once(): Failed opening 'C:\xampp\htdocs\surat_tugas\application\../vendor/autoload.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 8
ERROR - 2022-11-23 10:03:00 --> Severity: error --> Exception: Class 'Google_Client' not found C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 9
ERROR - 2022-11-23 04:03:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-11-23 10:03:05 --> Severity: Warning --> include_once(C:\xampp\htdocs\surat_tugas\application\../vendor/autoload.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 8
ERROR - 2022-11-23 10:03:05 --> Severity: Warning --> include_once(): Failed opening 'C:\xampp\htdocs\surat_tugas\application\../vendor/autoload.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 8
ERROR - 2022-11-23 10:03:05 --> Severity: error --> Exception: Class 'Google_Client' not found C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 9
ERROR - 2022-11-23 04:03:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-11-23 10:03:05 --> Severity: Warning --> include_once(C:\xampp\htdocs\surat_tugas\application\../vendor/autoload.php): failed to open stream: No such file or directory C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 8
ERROR - 2022-11-23 10:03:05 --> Severity: Warning --> include_once(): Failed opening 'C:\xampp\htdocs\surat_tugas\application\../vendor/autoload.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 8
ERROR - 2022-11-23 10:03:05 --> Severity: error --> Exception: Class 'Google_Client' not found C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 9
ERROR - 2022-11-23 04:03:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-11-23 10:19:49 --> Severity: error --> Exception: syntax error, unexpected 'redirect' (T_STRING), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 54
ERROR - 2022-11-23 10:19:49 --> Severity: error --> Exception: syntax error, unexpected 'redirect' (T_STRING), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 54
ERROR - 2022-11-23 10:24:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 50
ERROR - 2022-11-23 10:25:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 50
ERROR - 2022-11-23 10:25:42 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\surat_tugas\application\views\backend\main.php 8
ERROR - 2022-11-23 10:25:42 --> Severity: Notice --> Undefined variable: sidebar C:\xampp\htdocs\surat_tugas\application\views\backend\main.php 40
ERROR - 2022-11-23 10:25:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:25:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:25:44 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\surat_tugas\application\views\backend\main.php 8
ERROR - 2022-11-23 10:25:44 --> Severity: Notice --> Undefined variable: sidebar C:\xampp\htdocs\surat_tugas\application\views\backend\main.php 40
ERROR - 2022-11-23 10:25:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:25:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:26:07 --> Severity: Notice --> Undefined variable: sidebar C:\xampp\htdocs\surat_tugas\application\views\backend\main.php 40
ERROR - 2022-11-23 10:26:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:26:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:26:10 --> Severity: Notice --> Undefined variable: sidebar C:\xampp\htdocs\surat_tugas\application\views\backend\main.php 40
ERROR - 2022-11-23 10:26:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:26:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:26:11 --> Severity: Notice --> Undefined variable: sidebar C:\xampp\htdocs\surat_tugas\application\views\backend\main.php 40
ERROR - 2022-11-23 10:26:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:26:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:26:24 --> Severity: Notice --> Undefined variable: sidebar C:\xampp\htdocs\surat_tugas\application\views\backend\main.php 40
ERROR - 2022-11-23 10:26:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:26:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:26:29 --> Severity: Notice --> Undefined variable: sidebar C:\xampp\htdocs\surat_tugas\application\views\backend\main.php 40
ERROR - 2022-11-23 10:26:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:26:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:26:30 --> Severity: Notice --> Undefined variable: sidebar C:\xampp\htdocs\surat_tugas\application\views\backend\main.php 40
ERROR - 2022-11-23 10:26:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:26:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:26:35 --> Severity: Notice --> Undefined property: Login::$vars C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 52
ERROR - 2022-11-23 10:26:35 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\surat_tugas\application\views\backend\main.php 8
ERROR - 2022-11-23 10:26:35 --> Severity: Notice --> Undefined variable: sidebar C:\xampp\htdocs\surat_tugas\application\views\backend\main.php 40
ERROR - 2022-11-23 10:26:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:26:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:26:59 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\surat_tugas\application\views\backend\main.php 8
ERROR - 2022-11-23 10:26:59 --> Severity: Notice --> Undefined variable: sidebar C:\xampp\htdocs\surat_tugas\application\views\backend\main.php 40
ERROR - 2022-11-23 10:26:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:26:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:27:00 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\surat_tugas\application\views\backend\main.php 8
ERROR - 2022-11-23 10:27:00 --> Severity: Notice --> Undefined variable: sidebar C:\xampp\htdocs\surat_tugas\application\views\backend\main.php 40
ERROR - 2022-11-23 10:27:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:27:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:27:14 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\surat_tugas\application\views\backend\main.php 8
ERROR - 2022-11-23 10:27:14 --> Severity: Notice --> Undefined variable: sidebar C:\xampp\htdocs\surat_tugas\application\views\backend\main.php 40
ERROR - 2022-11-23 10:27:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:27:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:27:16 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\surat_tugas\application\views\backend\main.php 8
ERROR - 2022-11-23 10:27:16 --> Severity: Notice --> Undefined variable: sidebar C:\xampp\htdocs\surat_tugas\application\views\backend\main.php 40
ERROR - 2022-11-23 10:27:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:27:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:27:47 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 50
ERROR - 2022-11-23 10:27:50 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\surat_tugas\application\controllers\Login.php 50
ERROR - 2022-11-23 10:35:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:35:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:35:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 10:35:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:35:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:35:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:35:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:36:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:36:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:36:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 10:36:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:36:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:36:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:36:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:37:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:37:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:37:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 10:37:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:37:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:37:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:37:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:37:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:37:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:37:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 10:37:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:37:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:37:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:37:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:38:10 --> 404 Page Not Found: Dashbord/index
ERROR - 2022-11-23 10:38:23 --> 404 Page Not Found: Masuk/index
ERROR - 2022-11-23 10:38:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:38:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:38:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 10:38:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:38:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:38:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:38:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:38:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:38:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:38:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 10:38:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:38:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:38:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:38:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:39:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:39:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:39:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 10:39:16 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:39:16 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:39:16 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:39:16 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:49:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:49:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:49:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 10:49:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:49:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:49:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:49:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:53:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:53:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:53:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 10:53:36 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:53:36 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:53:36 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:53:36 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:53:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:53:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 10:53:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 10:53:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:53:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:53:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 10:53:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:05:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:05:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:05:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:05:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:05:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:05:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:05:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:05:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:05:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:05:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:05:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:05:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:05:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:05:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:05:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:05:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:05:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:05:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:05:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:05:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:05:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:05:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:05:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:05:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:08:35 --> Severity: error --> Exception: syntax error, unexpected 'login' (T_STRING), expecting ',' or ';' C:\xampp\htdocs\surat_tugas\application\views\welcome_message.php 128
ERROR - 2022-11-23 11:08:36 --> Severity: error --> Exception: syntax error, unexpected 'login' (T_STRING), expecting ',' or ';' C:\xampp\htdocs\surat_tugas\application\views\welcome_message.php 128
ERROR - 2022-11-23 11:15:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:15:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:15:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:18:02 --> 404 Page Not Found: Vendors/mdi
ERROR - 2022-11-23 11:18:02 --> 404 Page Not Found: Vendors/css
ERROR - 2022-11-23 11:19:17 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:19:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:19:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:20:08 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:20:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:20:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:20:31 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:20:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:20:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:21:21 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:21:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:21:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:21:22 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:21:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:21:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:21:50 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:21:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:21:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:22:03 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:22:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:22:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:22:39 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:22:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:22:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:22:40 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:22:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:22:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:22:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:22:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:22:55 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:23:20 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:23:20 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:23:20 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:23:22 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:23:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:23:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:24:42 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:24:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:24:43 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:24:43 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:25:14 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:25:14 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:25:15 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:25:15 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:25:21 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:25:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:25:21 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:25:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:25:56 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\surat_tugas\application\views\selamat.php 29
ERROR - 2022-11-23 11:25:57 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\surat_tugas\application\views\selamat.php 29
ERROR - 2022-11-23 11:26:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:26:27 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:26:28 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:26:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:26:39 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:26:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:27:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:27:08 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:27:09 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:27:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:27:10 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:27:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:28:52 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:28:52 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:28:53 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:28:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:28:54 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:28:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:28:54 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:28:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:28:56 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:28:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:30:05 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:30:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:30:05 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:30:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:30:19 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:30:19 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:30:20 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:30:20 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:30:21 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:30:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:30:31 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:30:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:30:53 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:30:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:31:23 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:31:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:31:32 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:31:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:31:33 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:31:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:31:40 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:31:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:31:48 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:31:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:31:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:31:49 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:31:56 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:31:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:32:02 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:32:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:32:02 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:32:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:33:02 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:33:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:33:24 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:33:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:33:24 --> 404 Page Not Found: Images/auth
ERROR - 2022-11-23 11:33:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:34:59 --> Severity: error --> Exception: Call to undefined function checkakun() C:\xampp\htdocs\surat_tugas\application\core\Admin_Controller.php 9
ERROR - 2022-11-23 11:35:00 --> Severity: error --> Exception: Call to undefined function checkakun() C:\xampp\htdocs\surat_tugas\application\core\Admin_Controller.php 9
ERROR - 2022-11-23 11:35:00 --> Severity: error --> Exception: Call to undefined function checkakun() C:\xampp\htdocs\surat_tugas\application\core\Admin_Controller.php 9
ERROR - 2022-11-23 11:35:01 --> Severity: error --> Exception: Call to undefined function checkakun() C:\xampp\htdocs\surat_tugas\application\core\Admin_Controller.php 9
ERROR - 2022-11-23 11:35:01 --> Severity: error --> Exception: Call to undefined function checkakun() C:\xampp\htdocs\surat_tugas\application\core\Admin_Controller.php 9
ERROR - 2022-11-23 11:35:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:35:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:35:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:35:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:35:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:35:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:35:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:35:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:35:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:35:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:35:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:35:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:35:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:35:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:35:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:35:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:35:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:35:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:35:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:35:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:35:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:36:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:36:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:36:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:36:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:36:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:36:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:36:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:36:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:36:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:36:06 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:36:06 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:36:06 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:37:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:37:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:37:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:37:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:37:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:37:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:37:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:37:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:37:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:37:44 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:37:44 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:37:44 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:37:44 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:41:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:41:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:41:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:41:30 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:41:30 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:41:30 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:41:30 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:45:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:45:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:45:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:46:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:46:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:46:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:46:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:46:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:46:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:46:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:46:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:46:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:46:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:46:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:46:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:46:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:46:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:46:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:48:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:48:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:48:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:57:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:57:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 11:57:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 11:57:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:57:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:57:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 11:57:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:02:59 --> Severity: error --> Exception: Call to undefined function checkakun() C:\xampp\htdocs\surat_tugas\application\core\Admin_Controller.php 9
ERROR - 2022-11-23 12:03:00 --> Severity: error --> Exception: Call to undefined function checkakun() C:\xampp\htdocs\surat_tugas\application\core\Admin_Controller.php 9
ERROR - 2022-11-23 12:03:01 --> Severity: error --> Exception: Call to undefined function checkakun() C:\xampp\htdocs\surat_tugas\application\core\Admin_Controller.php 9
ERROR - 2022-11-23 12:03:01 --> Severity: error --> Exception: Call to undefined function checkakun() C:\xampp\htdocs\surat_tugas\application\core\Admin_Controller.php 9
ERROR - 2022-11-23 12:03:01 --> Severity: error --> Exception: Call to undefined function checkakun() C:\xampp\htdocs\surat_tugas\application\core\Admin_Controller.php 9
ERROR - 2022-11-23 12:03:01 --> Severity: error --> Exception: Call to undefined function checkakun() C:\xampp\htdocs\surat_tugas\application\core\Admin_Controller.php 9
ERROR - 2022-11-23 12:03:01 --> Severity: error --> Exception: Call to undefined function checkakun() C:\xampp\htdocs\surat_tugas\application\core\Admin_Controller.php 9
ERROR - 2022-11-23 12:03:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:03:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:03:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:03:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:03:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:03:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:03:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:03:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:03:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:03:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:03:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:03:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:03:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:03:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:03:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:03:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:03:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:03:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:03:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:03:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:03:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:03:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:03:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:03:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:03:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:03:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:03:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:03:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:03:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:03:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:03:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:03:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:03:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:03:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:03:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:10:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:10:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:10:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:10:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:10:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:10:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:10:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:10:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:10:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:10:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:10:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:10:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:10:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:10:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:11:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:11:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:11:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:11:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:11:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:11:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:11:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:11:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:11:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:11:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:11:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:11:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:11:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:11:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:11:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:11:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:11:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:11:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:11:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:11:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:11:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:11:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:11:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:11:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:11:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:12:47 --> Query error: Unknown column 'admin_ptk' in 'where clause' - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_ptk` IS NULL
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:12:48 --> Query error: Unknown column 'admin_ptk' in 'where clause' - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_ptk` IS NULL
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:12:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:12:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:12:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:12:57 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:12:57 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:12:57 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:13:58 --> Severity: 4096 --> Object of class Google\Service\Oauth2\Userinfo could not be converted to string C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:13:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `id_surat` ASC' at line 5 - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = 
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:13:59 --> Severity: 4096 --> Object of class Google\Service\Oauth2\Userinfo could not be converted to string C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:13:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `id_surat` ASC' at line 5 - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = 
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:14:00 --> Severity: 4096 --> Object of class Google\Service\Oauth2\Userinfo could not be converted to string C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:14:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `id_surat` ASC' at line 5 - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = 
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:14:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:14:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:14:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:14:26 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:14:26 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:14:26 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:14:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:14:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:14:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:14:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:14:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:14:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:14:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:14:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:14:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:14:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:14:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:14:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:16:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:16:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:16:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:16:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:16:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:16:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:16:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:16:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:16:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:16:35 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:16:35 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:16:35 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:16:42 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:42 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:42 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:43 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:44 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:44 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:44 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:44 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:44 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:46 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:46 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:46 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:46 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:46 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:46 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:46 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:46 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:47 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:48 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:49 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:49 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:49 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:49 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:50 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:50 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:51 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:51 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:51 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:51 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:51 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:51 --> Severity: Notice --> Undefined variable: hasil C:\xampp\htdocs\surat_tugas\application\models\M_pegawai.php 47
ERROR - 2022-11-23 12:16:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:16:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:16:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:16:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:16:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:16:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:16:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:16:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:16:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:16:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:16:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:16:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:17:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:17:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:17:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:17:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:17:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:17:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:17:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:17:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:17:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:17:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:17:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:17:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:17:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:17:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:17:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:17:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:17:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:17:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:17:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:17:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:17:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:17:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:17:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:17:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:17:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:17:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:17:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:17:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:17:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:17:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:18:06 --> Severity: 4096 --> Object of class Google\Service\Oauth2\Userinfo could not be converted to string C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:18:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `id_surat` ASC' at line 5 - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = 
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:18:07 --> Severity: 4096 --> Object of class Google\Service\Oauth2\Userinfo could not be converted to string C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:18:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `id_surat` ASC' at line 5 - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = 
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:18:07 --> Severity: 4096 --> Object of class Google\Service\Oauth2\Userinfo could not be converted to string C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:18:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `id_surat` ASC' at line 5 - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = 
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:18:07 --> Severity: 4096 --> Object of class Google\Service\Oauth2\Userinfo could not be converted to string C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:18:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `id_surat` ASC' at line 5 - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = 
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:18:08 --> Severity: 4096 --> Object of class Google\Service\Oauth2\Userinfo could not be converted to string C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:18:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `id_surat` ASC' at line 5 - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = 
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:19:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:19:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:19:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:19:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:19:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:19:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:19:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:19:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:19:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:19:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:19:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:19:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:19:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:20:01 --> Severity: Notice --> Undefined variable: user_data C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:20:01 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:20:01 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = Array
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:20:02 --> Severity: Notice --> Undefined variable: user_data C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:20:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:20:02 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = Array
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:20:02 --> Severity: Notice --> Undefined variable: user_data C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:20:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:20:02 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = Array
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:20:21 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:20:21 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:20:31 --> Severity: error --> Exception: syntax error, unexpected 'mt_pegawai' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 13
ERROR - 2022-11-23 12:20:32 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:20:32 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:20:32 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:20:33 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:20:33 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:20:33 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:20:33 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:20:34 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:20:34 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:20:34 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:20:34 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:20:34 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:21:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:21:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:21:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:21:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:21:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:21:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:21:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:21:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:21:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:21:30 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:21:30 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:21:30 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:22:53 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:22:54 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:23:21 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ']' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:23:22 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ']' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:23:22 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ']' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:23:23 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ']' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:23:23 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ']' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:23:23 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ']' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:23:27 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:23:27 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:23:28 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:23:28 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:23:37 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:23:38 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:23:38 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:23:38 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:24:32 --> Severity: 4096 --> Object of class Google\Service\Oauth2\Userinfo could not be converted to string C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:24:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `id_surat` ASC' at line 5 - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = 
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:25:48 --> Severity: 4096 --> Object of class Google\Service\Oauth2\Userinfo could not be converted to string C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:25:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `id_surat` ASC' at line 5 - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = 
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:25:49 --> Severity: 4096 --> Object of class Google\Service\Oauth2\Userinfo could not be converted to string C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:25:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `id_surat` ASC' at line 5 - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = 
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:25:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:25:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:25:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:25:58 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:25:58 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:25:58 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:25:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:25:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:25:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:25:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:25:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:25:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:25:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:25:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:25:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:25:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:25:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:25:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:26:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:26:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:26:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:26:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:26:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:26:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:26:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:26:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:26:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:26:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:26:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:26:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:26:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:26:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:26:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:26:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:26:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:26:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:26:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:26:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:26:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:26:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:26:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:26:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:01 --> Severity: Notice --> Undefined variable: user_data C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:28:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:28:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:28:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:28:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:03 --> Severity: Notice --> Undefined variable: user_data C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:28:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:28:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:28:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:28:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:06 --> Severity: Notice --> Undefined variable: user_data C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:28:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:28:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:28:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:28:06 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:06 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:06 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:28:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:28:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:28:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:28:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:28:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:28:25 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:25 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:25 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:28:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:28:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:28:26 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:26 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:26 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:28:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:28:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:28:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:28:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:28:41 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:28:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:28:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:28:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:28:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:28:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:28:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:28:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:28:43 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:29:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:29 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:29 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:29:30 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:30 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:30 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:30 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:29:30 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:30 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:30 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:30 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:29:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:29:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:29:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:29:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:29:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:29:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:29:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:29:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:29:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:29:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:29:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:30:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:30:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:30:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:25 --> Severity: error --> Exception: syntax error, unexpected '.' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:30:26 --> Severity: error --> Exception: syntax error, unexpected '.' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:30:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:30:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:30:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:30:36 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:36 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:36 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:30:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:30:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:30:36 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:36 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:36 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:30:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:30:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:30:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:30:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:30:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:30:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:30:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:30:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:30:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:30:40 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:30:40 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:30:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:30:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:30:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:30:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:30:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:31:56 --> Severity: error --> Exception: syntax error, unexpected 'user_data' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 12
ERROR - 2022-11-23 12:31:57 --> Severity: error --> Exception: syntax error, unexpected 'user_data' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 12
ERROR - 2022-11-23 12:32:03 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:32:04 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:32:04 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:32:19 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 12
ERROR - 2022-11-23 12:32:19 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 12
ERROR - 2022-11-23 12:32:35 --> Severity: error --> Exception: syntax error, unexpected '.' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 12
ERROR - 2022-11-23 12:32:36 --> Severity: error --> Exception: syntax error, unexpected '.' C:\xampp\htdocs\surat_tugas\application\models\M_st.php 12
ERROR - 2022-11-23 12:32:59 --> Severity: Compile Error --> Can't use method return value in write context C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:33:00 --> Severity: Compile Error --> Can't use method return value in write context C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:33:26 --> Severity: Compile Error --> Can't use method return value in write context C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:33:26 --> Severity: Compile Error --> Can't use method return value in write context C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:33:27 --> Severity: Compile Error --> Can't use method return value in write context C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:33:27 --> Severity: Compile Error --> Can't use method return value in write context C:\xampp\htdocs\surat_tugas\application\models\M_st.php 11
ERROR - 2022-11-23 12:33:41 --> Severity: 4096 --> Object of class Google\Service\Oauth2\Userinfo could not be converted to string C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:33:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `id_surat` ASC' at line 5 - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = 
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:33:41 --> Severity: 4096 --> Object of class Google\Service\Oauth2\Userinfo could not be converted to string C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:33:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `id_surat` ASC' at line 5 - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = 
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:33:42 --> Severity: 4096 --> Object of class Google\Service\Oauth2\Userinfo could not be converted to string C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:33:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `id_surat` ASC' at line 5 - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = 
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:33:42 --> Severity: 4096 --> Object of class Google\Service\Oauth2\Userinfo could not be converted to string C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:33:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `id_surat` ASC' at line 5 - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = 
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:33:43 --> Severity: 4096 --> Object of class Google\Service\Oauth2\Userinfo could not be converted to string C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:33:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `id_surat` ASC' at line 5 - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = 
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:33:43 --> Severity: 4096 --> Object of class Google\Service\Oauth2\Userinfo could not be converted to string C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:33:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `id_surat` ASC' at line 5 - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = 
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:33:43 --> Severity: 4096 --> Object of class Google\Service\Oauth2\Userinfo could not be converted to string C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:33:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `id_surat` ASC' at line 5 - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = 
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:33:44 --> Severity: 4096 --> Object of class Google\Service\Oauth2\Userinfo could not be converted to string C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:33:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `id_surat` ASC' at line 5 - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = 
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:33:44 --> Severity: 4096 --> Object of class Google\Service\Oauth2\Userinfo could not be converted to string C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:33:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `id_surat` ASC' at line 5 - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = 
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:33:44 --> Severity: 4096 --> Object of class Google\Service\Oauth2\Userinfo could not be converted to string C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:33:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `id_surat` ASC' at line 5 - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = 
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:33:44 --> Severity: 4096 --> Object of class Google\Service\Oauth2\Userinfo could not be converted to string C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:33:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `id_surat` ASC' at line 5 - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = 
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:33:44 --> Severity: 4096 --> Object of class Google\Service\Oauth2\Userinfo could not be converted to string C:\xampp\htdocs\surat_tugas\system\database\DB_query_builder.php 2443
ERROR - 2022-11-23 12:33:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `id_surat` ASC' at line 5 - Invalid query: SELECT *
FROM `dt_surat`
JOIN `mt_pegawai` ON `mt_pegawai`.`nip` = `dt_surat`.`nip`
WHERE `admin_surat` = 
ORDER BY `id_surat` ASC
ERROR - 2022-11-23 12:33:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:33:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:33:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:33:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:33:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:33:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:33:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:33:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 12:33:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 12:33:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:33:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 12:33:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:51:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:51:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:51:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 15:51:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:51:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:51:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:51:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:51:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:51:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:51:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 15:51:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:51:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:51:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:51:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:51:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 15:51:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:51:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:51:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:51:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:57:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:57:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:57:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 15:57:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:57:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:57:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:57:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:57:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:57:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 15:57:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:57:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:57:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:57:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:57:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:57:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 15:57:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:57:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:57:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:57:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:57:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:57:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 15:57:35 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:57:35 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:57:35 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:57:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:57:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:57:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 15:57:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:57:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:57:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:57:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:57:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:57:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 15:57:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:57:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:57:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:58:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:58:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:58:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 15:58:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:58:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:58:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:59:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:59:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:59:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 15:59:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:59:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:59:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:59:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:59:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:59:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 15:59:06 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:59:06 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:59:06 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:59:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:59:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 15:59:15 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:59:15 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:59:15 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:59:15 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:59:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:59:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:59:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 15:59:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:59:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:59:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:59:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:59:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 15:59:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 15:59:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:59:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 15:59:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:00:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:00:04 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:00:04 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:00:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:00:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:00:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:01:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:01:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:01:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:01:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:01:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:01:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:01:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:01:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:01:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:01:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:01:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:01:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:01:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:01:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:01:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:01:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:01:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:01:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:01:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:01:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:01:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:01:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:01:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:01:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:02:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:02:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:02:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:02:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:02:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:02:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:02:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:02:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:02:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:02:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:02:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:02:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:02:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:02:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:02:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:02:35 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:02:35 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:02:35 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:03:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:03:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:03:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:03:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:03:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:03:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:03:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:03:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:03:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:03:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:03:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:03:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:03:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:03:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:03:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:03:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:03:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:03:52 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:52 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:52 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:03:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:03:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:03:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:03:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:03:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:03:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:03:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:04:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:04:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:04:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:04:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:04:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:04:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:06:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:06:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:06:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:06:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:06:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:06:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:07:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:07:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:07:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:07:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:07:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:07:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:07:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:07:06 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:07:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:07:06 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:07:06 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:07:06 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:07:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:07:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:07:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:07:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:07:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:07:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:07:18 --> Severity: error --> Exception: Call to undefined method M_pptk::update() C:\xampp\htdocs\surat_tugas\application\controllers\master\Pptk.php 88
ERROR - 2022-11-23 16:07:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:07:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:07:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:07:43 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:07:43 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:07:43 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:08:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:08:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:08:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:08:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:08:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:08:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:08:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:08:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:08:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:08:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:08:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:08:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:16 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:16 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:09:16 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:16 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:16 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:09:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:09:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:09:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:25 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:25 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:25 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:09:25 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:25 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:25 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:09:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:09:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:09:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:09:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:09:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:09:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:09:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:09:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:09:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:09:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:09:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:14:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:14:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:14:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:14:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:14:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:14:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:14:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:14:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:14:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:14:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:14:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:14:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:15:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:15:19 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:15:19 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:15:19 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:15:19 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:15:20 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:15:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:15:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:15:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:15:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:15:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:15:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:15:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:15:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:15:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:15:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:15:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:15:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:15:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:15:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:15:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:15:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:15:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:15:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:15:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:15:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:15:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:15:44 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:15:44 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:15:44 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:15:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:15:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:15:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:15:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:15:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:15:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:15:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:15:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:15:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:15:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:15:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:15:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:16:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:16:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:16:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:16:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:16:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:16:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:16:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:16:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:16:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:16:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:16:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:16:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:16:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:16:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:16:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:16:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:16:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:16:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:16:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:16:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:16:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:16:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:16:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:16:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:16:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:16:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:16:58 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:58 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:58 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:16:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:16:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:16:58 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:58 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:16:58 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:17:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:17:00 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:17:00 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:17:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:17:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:17:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:17:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:17:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:17:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:17:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:17:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:17:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:17:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:17:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:17:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:17:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:17:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:17:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:17:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:17:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:17:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:17:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:17:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:17:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:17:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:17:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:17:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:17:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:17:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:17:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:18:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:18:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:18:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:18:20 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:18:20 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:18:20 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:18:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:18:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:18:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:18:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:18:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:18:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:18:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:18:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:18:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:18:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:18:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:18:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:11 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:19:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:20 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:20 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:19:20 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:20 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:20 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:21 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:21 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:19:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:19:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:19:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:19:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:34 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:19:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:19:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:19:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:19:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:19:43 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:43 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:43 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:19:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:19:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:19:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:19:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:19:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:19:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:19:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:51 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:51 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:19:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:52 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:19:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:19:52 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:52 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:19:52 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:21:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:21:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:21:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:21:43 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:21:43 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:21:43 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:32:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:32:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:32:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:32:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:32:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:32:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:33:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:33:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:33:43 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:33:43 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:33:43 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:33:43 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:33:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:33:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:33:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:33:44 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:33:44 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:33:44 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:33:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:33:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:33:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:33:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:33:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:33:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:34:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:34:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:34:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:34:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:34:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:34:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:34:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:34:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:34:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:34:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:34:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:34:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:34:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:34:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:34:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:34:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:34:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:34:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:34:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:34:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:34:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:34:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:34:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:34:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:34:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:34:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:34:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:34:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:34:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:34:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:34:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:35:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:35:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:35:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:35:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:35:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:35:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:35:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:35:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:35:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:35:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:35:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:35:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:36:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:36:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:36:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:36:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:36:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:36:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:37:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:37:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:37:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:37:25 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:37:25 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:37:25 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:38:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:38:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:38:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:38:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:38:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:38:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:38:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:38:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:38:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:38:44 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:38:44 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:38:44 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:39:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:39:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:39:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:39:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:39:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:39:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:39:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:39:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:39:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:39:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:39:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:39:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:39:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:39:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:39:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:39:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:39:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:39:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:40:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:40:12 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:40:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:40:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:40:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:40:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:40:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:40:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:40:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:40:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:40:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:40:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:40:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:40:13 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:40:13 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:40:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:40:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:40:14 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:40:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:40:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:40:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:40:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:40:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:40:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:40:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:40:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:40:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:40:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:40:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:40:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:40:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:40:27 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:40:27 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:40:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:40:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:40:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:40:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:40:28 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:40:28 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:40:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:40:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:40:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:41:05 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:41:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:41:05 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:41:06 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:41:06 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:41:06 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:41:06 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:41:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:41:50 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:41:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:41:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:41:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:41:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:42:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:44:50 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:48:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:48:33 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:48:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:48:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:48:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:48:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:50:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:50:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:50:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:50:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:50:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:50:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:51:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:51:01 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:51:01 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:51:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:51:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:51:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:51:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:51:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:51:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:51:57 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:51:57 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:51:57 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:52:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:52:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:52:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:52:07 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:52:07 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:52:07 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:52:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:52:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:52:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:52:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:52:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:52:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:52:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:52:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:52:44 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:52:44 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:52:44 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:52:44 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:52:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:52:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:52:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:52:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:52:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:52:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:54:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:54:36 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:54:36 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:54:36 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:54:36 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:54:36 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:55:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:55:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:55:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:55:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:55:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:55:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:55:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:55:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:55:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:55:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:55:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:55:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:55:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:55:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:55:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:55:57 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:55:57 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:55:57 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:56:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:56:09 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:56:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:56:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:56:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:56:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:56:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:56:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:56:22 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:56:22 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:56:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:56:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:56:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:56:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:56:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:56:26 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 16:56:26 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 16:56:26 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:56:26 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 16:56:26 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:03:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:03:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:03:46 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:03:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:03:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:03:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:03:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:03:53 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:03:53 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:03:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:03:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:03:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:03:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:03:54 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:03:54 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:03:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:03:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:03:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:03:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:03:55 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:03:55 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:03:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:03:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:03:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:04:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:04:17 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:04:17 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:04:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:04:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:04:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:04:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:04:18 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:04:18 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:04:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:04:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:04:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:08:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:08:25 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:08:25 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:08:25 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:08:25 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:08:25 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:09:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:09:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:09:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:09:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:09:25 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:09:25 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:09:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:09:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:09:35 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:09:35 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:09:35 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:09:35 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:09:35 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:10:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:10:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:10:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:10:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:10:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:10:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:10:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:10:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:10:27 --> 404 Page Not Found: patch/Master_patch/pacth
ERROR - 2022-11-23 17:10:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:10:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:10:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:10:57 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:10:57 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:10:57 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:10:58 --> Severity: error --> Exception: Call to undefined function __master() C:\xampp\htdocs\surat_tugas\application\views\settings\patch.php 4
ERROR - 2022-11-23 17:10:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:10:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:10:58 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:10:58 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:12:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:12:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:12:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:12:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:12:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:12:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:12:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:12:23 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:12:23 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:12:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:12:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:12:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:12:42 --> Severity: Notice --> Undefined variable: st C:\xampp\htdocs\surat_tugas\application\views\settings\patch.php 54
ERROR - 2022-11-23 17:12:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\surat_tugas\application\views\settings\patch.php 54
ERROR - 2022-11-23 17:12:42 --> Severity: Notice --> Undefined variable: st C:\xampp\htdocs\surat_tugas\application\views\settings\patch.php 135
ERROR - 2022-11-23 17:12:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\surat_tugas\application\views\settings\patch.php 135
ERROR - 2022-11-23 17:12:42 --> Severity: Notice --> Undefined variable: st C:\xampp\htdocs\surat_tugas\application\views\settings\patch.php 189
ERROR - 2022-11-23 17:12:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\surat_tugas\application\views\settings\patch.php 189
ERROR - 2022-11-23 17:12:42 --> Severity: Notice --> Undefined variable: st C:\xampp\htdocs\surat_tugas\application\views\settings\patch.php 348
ERROR - 2022-11-23 17:12:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\surat_tugas\application\views\settings\patch.php 348
ERROR - 2022-11-23 17:12:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:12:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:12:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:12:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:12:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:12:43 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:13:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:13:37 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:13:37 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:13:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:13:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:13:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:13:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:13:38 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:13:38 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:13:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:13:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:13:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:13:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:13:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:13:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:13:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:13:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:13:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:13:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:13:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:13:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:13:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:13:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:13:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:13:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:13:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:13:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:13:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:13:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:13:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:14:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:14:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:14:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:14:07 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:14:07 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:14:07 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:14:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:14:08 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:14:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:14:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:14:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:14:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:14:32 --> Severity: error --> Exception: Call to undefined function __dwi() C:\xampp\htdocs\surat_tugas\application\views\settings\patch.php 19
ERROR - 2022-11-23 17:14:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:14:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:14:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:14:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:14:34 --> Severity: error --> Exception: Call to undefined function __dwi() C:\xampp\htdocs\surat_tugas\application\views\settings\patch.php 19
ERROR - 2022-11-23 17:14:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:14:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:14:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:14:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:14:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:14:42 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:14:42 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:14:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:14:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:14:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:15:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:15:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:15:10 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:15:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:15:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:15:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:15:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:15:24 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:15:24 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:15:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:15:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:15:24 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:15:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:15:31 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:15:31 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:15:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:15:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:15:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:15:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:15:32 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:15:32 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:15:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:15:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:15:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:16:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:16:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:16:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:16:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:16:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:16:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:16:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:16:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:16:45 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:16:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:16:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:16:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:16:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:16:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:16:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:16:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:16:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:16:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:16:48 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:16:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:16:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:16:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:16:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:16:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:16:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:16:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:16:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:16:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:16:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:16:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:16:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:16:49 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:16:49 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:16:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:16:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:16:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:17:55 --> The upload path does not appear to be valid.
ERROR - 2022-11-23 17:17:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:17:56 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:17:56 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:17:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:17:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:17:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:17:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:17:57 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:17:57 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:17:57 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:17:57 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:17:57 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:17:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:17:58 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:17:58 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:17:58 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:17:58 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:17:58 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:17:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:17:59 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:17:59 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:17:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:17:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:17:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:18:39 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:18:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:18:39 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:18:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:18:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:18:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:19:02 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:19:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:19:02 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:19:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:19:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:19:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:19:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:19:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:19:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:19:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:19:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:19:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:19:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:19:14 --> 404 Page Not Found: Assets/css
ERROR - 2022-11-23 17:19:14 --> 404 Page Not Found: Assets/js
ERROR - 2022-11-23 17:19:15 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:19:15 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:19:15 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-11-23 17:19:15 --> 404 Page Not Found: Fonts/Rubik
