<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-27 08:56:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:56:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:56:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:56:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:56:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:56:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:56:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 13:56:49 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 13:56:49 --> 404 Page Not Found: Css/owl.carousel.min.css
ERROR - 2022-10-27 13:56:49 --> 404 Page Not Found: Css/bootstrap.min.css
ERROR - 2022-10-27 13:56:49 --> 404 Page Not Found: Js/jquery-3.3.1.min.js
ERROR - 2022-10-27 08:56:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 13:56:49 --> 404 Page Not Found: Css/style.css
ERROR - 2022-10-27 13:56:49 --> 404 Page Not Found: Js/popper.min.js
ERROR - 2022-10-27 08:56:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:56:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:56:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 13:56:50 --> 404 Page Not Found: Images/undraw_remotely_2j6y.svg
ERROR - 2022-10-27 13:56:50 --> 404 Page Not Found: Js/main.js
ERROR - 2022-10-27 08:56:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:56:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 13:56:50 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-10-27 08:56:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:56:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:56:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:56:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 13:56:50 --> 404 Page Not Found: Css/owl.carousel.min.css
ERROR - 2022-10-27 13:56:50 --> 404 Page Not Found: Css/bootstrap.min.css
ERROR - 2022-10-27 13:56:50 --> 404 Page Not Found: Js/jquery-3.3.1.min.js
ERROR - 2022-10-27 08:56:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 13:56:50 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 13:56:50 --> 404 Page Not Found: Js/popper.min.js
ERROR - 2022-10-27 13:56:50 --> 404 Page Not Found: Css/style.css
ERROR - 2022-10-27 08:56:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:56:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 13:56:50 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-10-27 13:56:50 --> 404 Page Not Found: Js/main.js
ERROR - 2022-10-27 13:56:50 --> 404 Page Not Found: Images/undraw_remotely_2j6y.svg
ERROR - 2022-10-27 08:56:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:56:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:56:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:56:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:56:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:56:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:56:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 13:56:50 --> 404 Page Not Found: Js/jquery-3.3.1.min.js
ERROR - 2022-10-27 13:56:50 --> 404 Page Not Found: Js/popper.min.js
ERROR - 2022-10-27 13:56:50 --> 404 Page Not Found: Css/owl.carousel.min.css
ERROR - 2022-10-27 13:56:50 --> 404 Page Not Found: Css/bootstrap.min.css
ERROR - 2022-10-27 13:56:50 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 08:56:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 13:56:50 --> 404 Page Not Found: Css/style.css
ERROR - 2022-10-27 08:56:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:56:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 13:56:50 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-10-27 13:56:50 --> 404 Page Not Found: Js/main.js
ERROR - 2022-10-27 13:56:50 --> 404 Page Not Found: Images/undraw_remotely_2j6y.svg
ERROR - 2022-10-27 08:59:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 13:59:24 --> 404 Page Not Found: Js/jquery-3.3.1.min.js
ERROR - 2022-10-27 13:59:24 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 13:59:24 --> 404 Page Not Found: Js/popper.min.js
ERROR - 2022-10-27 08:59:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 13:59:24 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-10-27 13:59:24 --> 404 Page Not Found: Images/undraw_remotely_2j6y.svg
ERROR - 2022-10-27 13:59:24 --> 404 Page Not Found: Js/main.js
ERROR - 2022-10-27 08:59:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 13:59:42 --> 404 Page Not Found: Js/main.js
ERROR - 2022-10-27 13:59:42 --> 404 Page Not Found: Images/undraw_remotely_2j6y.svg
ERROR - 2022-10-27 13:59:42 --> 404 Page Not Found: Js/jquery-3.3.1.min.js
ERROR - 2022-10-27 13:59:42 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 13:59:42 --> 404 Page Not Found: Js/popper.min.js
ERROR - 2022-10-27 13:59:42 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-10-27 08:59:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 13:59:43 --> 404 Page Not Found: Js/popper.min.js
ERROR - 2022-10-27 13:59:43 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 08:59:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 13:59:43 --> 404 Page Not Found: Js/jquery-3.3.1.min.js
ERROR - 2022-10-27 13:59:43 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-10-27 13:59:43 --> 404 Page Not Found: Js/main.js
ERROR - 2022-10-27 13:59:43 --> 404 Page Not Found: Images/undraw_remotely_2j6y.svg
ERROR - 2022-10-27 08:59:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 08:59:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 13:59:44 --> 404 Page Not Found: Js/popper.min.js
ERROR - 2022-10-27 13:59:44 --> 404 Page Not Found: Js/jquery-3.3.1.min.js
ERROR - 2022-10-27 13:59:44 --> 404 Page Not Found: Images/undraw_remotely_2j6y.svg
ERROR - 2022-10-27 13:59:44 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 13:59:44 --> 404 Page Not Found: Js/main.js
ERROR - 2022-10-27 13:59:44 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-10-27 08:59:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:00:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:00:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:00:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:00:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:00:00 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 14:00:00 --> 404 Page Not Found: Js/jquery-3.3.1.min.js
ERROR - 2022-10-27 14:00:00 --> 404 Page Not Found: Js/popper.min.js
ERROR - 2022-10-27 09:00:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:00:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:00:00 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-10-27 14:00:00 --> 404 Page Not Found: Js/main.js
ERROR - 2022-10-27 14:00:00 --> 404 Page Not Found: Images/undraw_remotely_2j6y.svg
ERROR - 2022-10-27 09:02:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:02:39 --> 404 Page Not Found: Js/popper.min.js
ERROR - 2022-10-27 14:02:39 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 14:02:39 --> 404 Page Not Found: Js/main.js
ERROR - 2022-10-27 14:02:39 --> 404 Page Not Found: Js/jquery-3.3.1.min.js
ERROR - 2022-10-27 14:02:39 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-10-27 14:02:39 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-27 09:02:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:02:41 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-27 14:02:41 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-10-27 14:02:41 --> 404 Page Not Found: Js/main.js
ERROR - 2022-10-27 14:02:41 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 14:02:41 --> 404 Page Not Found: Js/popper.min.js
ERROR - 2022-10-27 14:02:41 --> 404 Page Not Found: Js/jquery-3.3.1.min.js
ERROR - 2022-10-27 09:02:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Js/popper.min.js
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Js/jquery-3.3.1.min.js
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Js/main.js
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Js/main.js
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Js/popper.min.js
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Js/jquery-3.3.1.min.js
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Js/popper.min.js
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Js/jquery-3.3.1.min.js
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Js/main.js
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Js/jquery-3.3.1.min.js
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Js/popper.min.js
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Js/main.js
ERROR - 2022-10-27 14:02:42 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-10-27 09:02:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:02:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:02:52 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 14:02:52 --> 404 Page Not Found: Js/popper.min.js
ERROR - 2022-10-27 14:02:52 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-10-27 14:02:52 --> 404 Page Not Found: Js/main.js
ERROR - 2022-10-27 14:02:52 --> 404 Page Not Found: Js/jquery-3.3.1.min.js
ERROR - 2022-10-27 09:03:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:03:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:03:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:03:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:03:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:03:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:03:07 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 14:03:07 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-10-27 14:03:07 --> 404 Page Not Found: Js/popper.min.js
ERROR - 2022-10-27 14:03:07 --> 404 Page Not Found: Js/main.js
ERROR - 2022-10-27 14:03:07 --> 404 Page Not Found: Js/jquery-3.3.1.min.js
ERROR - 2022-10-27 09:04:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:04:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:04:00 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:04:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:04:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:04:01 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:05:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:05:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:05:26 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:05:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:05:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:05:27 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:05:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:05:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:05:27 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:05:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:05:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:05:28 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:05:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:05:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:05:28 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:05:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:05:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:05:28 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:05:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:05:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:05:28 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:05:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:05:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:05:28 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:05:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:05:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:05:28 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:06:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:02 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:06:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:03 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:06:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:11 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:06:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:11 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:06:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:11 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:06:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:12 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:06:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:13 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:06:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:14 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:06:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:14 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:06:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:14 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:06:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:20 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:06:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:20 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:06:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:21 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:06:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:21 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:06:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:21 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:06:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:22 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:06:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:22 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:06:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:24 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:06:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:24 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:06:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:25 --> 404 Page Not Found: Fonts/icomoon
ERROR - 2022-10-27 09:06:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:06:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:42 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:06:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:43 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:06:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:06:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:06:43 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:07:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:07:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:08:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:08:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:08:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:08:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:09:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:09:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:09:39 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\sppd\application\views\welcome_message.php 20
ERROR - 2022-10-27 09:09:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:09:40 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\sppd\application\views\welcome_message.php 20
ERROR - 2022-10-27 09:10:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:10:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:10:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:10:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:10:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:11:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:11:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:11:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 14:11:03 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 09:11:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:11:03 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 09:11:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:11:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:11:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:11:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:11:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:11:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:11:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:11:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:11:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:11:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:12:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:12:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:12:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:12:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:12:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:12:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:12:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:12:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:12:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:12:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:12:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:12:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:12:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:12:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:12:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:12:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:12:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:12:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:12:35 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:14:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:15:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:15:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:15:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:15:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:15:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:15:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:16:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:16:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:16:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:16:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:16:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:16:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:16:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:16:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:16:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:16:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:16:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:17:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:17:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:18:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:18:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:18:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:18:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:18:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:18:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:27:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:27:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:27:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:27:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:27:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:27:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:28:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:28:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:28:59 --> Severity: Notice --> Undefined index: password C:\xampp\htdocs\sppd\application\controllers\auth\Login.php 24
ERROR - 2022-10-27 09:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:29:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:29:07 --> Severity: Notice --> Undefined index: password C:\xampp\htdocs\sppd\application\controllers\auth\Login.php 24
ERROR - 2022-10-27 09:29:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:29:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:29:18 --> Severity: Notice --> Undefined index: password C:\xampp\htdocs\sppd\application\controllers\auth\Login.php 24
ERROR - 2022-10-27 09:29:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:30:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:30:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:30:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:30:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:30:16 --> 404 Page Not Found: Dashboard/index
ERROR - 2022-10-27 09:31:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:31:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:31:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:31:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:31:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:32:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:32:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:32:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:32:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:32:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:32:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:32:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:32:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:32:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:32:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:32:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:32:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:32:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:32:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:50:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:50:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:50:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:51:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:51:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:51:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:51:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:51:56 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:51:56 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:51:56 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:51:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:51:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:51:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:51:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:51:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:51:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:51:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:51:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:51:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:51:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:51:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:51:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:51:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:51:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:51:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:51:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:51:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:52:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:52:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:52:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:52:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:52:39 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:52:39 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:52:39 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:52:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:52:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:52:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:52:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:52:40 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:52:40 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:52:40 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:52:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:52:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:52:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:52:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:52:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:52:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:52:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:52:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:52:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:52:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:52:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:52:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:52:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:52:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:52:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:52:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:52:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:52:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:52:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:52:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:52:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:52:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:52:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:52:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:52:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:52:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:52:55 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:52:55 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:52:55 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:52:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:52:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:52:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:52:55 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:52:55 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:52:55 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:53:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 14:53:41 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 09:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:53:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 14:53:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 09:53:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:43 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:43 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:43 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:53:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 14:53:43 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 09:53:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:43 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:43 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:43 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 14:53:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 09:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:44 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:44 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:44 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 14:53:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 09:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:44 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:44 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:44 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 14:53:44 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 09:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:44 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:44 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:44 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:53:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 14:53:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 09:53:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:45 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:45 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:45 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:53:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 14:53:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 09:53:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:45 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:45 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:45 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:53:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 14:53:45 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 09:53:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:45 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:45 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:45 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:53:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 14:53:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 09:53:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:46 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:46 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:46 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:53:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 14:53:46 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 09:53:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:46 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:46 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:46 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:53:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:47 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 09:53:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:48 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 09:53:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:48 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:48 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:53:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:48 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:53:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 14:53:52 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 09:53:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:53:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:53:52 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:52 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:53:52 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:55:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:55:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:55:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:55:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 14:55:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 09:55:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:55:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:55:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:55:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:55:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:55:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:55:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:55:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:55:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:55:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 14:55:07 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 09:55:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:55:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:55:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:55:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:55:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:55:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:55:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:55:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:55:12 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 09:55:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:55:12 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:55:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:56:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:56:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:56:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:56:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:56:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 14:56:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 14:56:33 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 09:56:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:56:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:56:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:56:33 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:56:33 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:56:33 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:56:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:56:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:56:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:56:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:56:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 14:56:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 14:56:34 --> 404 Page Not Found: Assets/css
ERROR - 2022-10-27 09:56:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:56:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:56:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:56:34 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:56:34 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:56:34 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:56:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:56:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:56:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:56:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:56:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:56:59 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:56:59 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:56:59 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:57:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:57:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:57:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 09:57:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 14:57:00 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:57:00 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 14:57:00 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 09:57:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:00:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:00:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:00:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:00:25 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:00:25 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:00:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:00:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:00:25 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:00:25 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:02:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:02:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:02:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:02:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:02:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:02:40 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:02:40 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:02:40 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:02:40 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:02:42 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:02:42 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:02:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:02:42 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:02:42 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:04:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:04:31 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:04:31 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:04:31 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:04:31 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:04:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:04:32 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:04:32 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:04:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:04:32 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:04:32 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:04:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:04:32 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:04:32 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:04:32 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:04:33 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:04:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:04:33 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:04:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:04:33 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:04:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:04:33 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:04:33 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:04:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:04:33 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:04:33 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:04:33 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:04:33 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:04:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:04:34 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:04:34 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:04:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:04:34 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:04:34 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:04:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:04:34 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:04:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:04:34 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:04:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:04:34 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:04:34 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:04:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:04:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:04:34 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:04:34 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:04:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:04:34 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:04:34 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:05:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:05:38 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:05:38 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:05:38 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:05:38 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:05:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:05:39 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:05:39 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:05:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:05:39 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:05:39 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:05:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:05:39 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:05:39 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:05:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:05:39 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:05:39 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:05:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:05:40 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:05:40 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:05:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:05:40 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:05:40 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:05:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:05:40 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:05:40 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:05:40 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:05:40 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:05:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:05:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:05:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:05:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:05:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:05:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:05:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:05:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:05:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:05:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:05:41 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:06:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:06:21 --> Severity: error --> Exception: Call to undefined function __imgh() C:\xampp\htdocs\sppd\application\views\backend\main.php 34
ERROR - 2022-10-27 10:06:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:06:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:06:21 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:06:21 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:06:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:06:22 --> Severity: error --> Exception: Call to undefined function __imgh() C:\xampp\htdocs\sppd\application\views\backend\main.php 34
ERROR - 2022-10-27 10:06:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:06:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:06:22 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:06:22 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:06:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:06:28 --> Severity: error --> Exception: Call to undefined function __imgh() C:\xampp\htdocs\sppd\application\views\backend\main.php 34
ERROR - 2022-10-27 10:06:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:06:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:06:28 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:06:28 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:06:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:06:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:06:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:06:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:06:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:06:28 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:06:28 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:06:28 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:06:28 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:06:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:06:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:06:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:06:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:06:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:06:29 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:06:29 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:06:29 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:06:29 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:06:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:06:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:06:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:06:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:06:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:06:30 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:06:30 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:06:30 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:06:30 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:06:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:06:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:06:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:06:30 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:06:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:06:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:06:30 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:06:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:06:30 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:06:30 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:06:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:06:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:06:30 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:06:30 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:06:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:06:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:06:30 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:06:30 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:09:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:09:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:09:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:09:29 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:09:29 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:09:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:09:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:09:29 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:09:29 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:09:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:09:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:09:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:09:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:09:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:09:31 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:09:31 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:09:31 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:09:31 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:11:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:11:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:11:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:11:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:11:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:11:52 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:11:52 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:11:52 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:11:52 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:11:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:11:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:11:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:11:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:11:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:11:53 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:11:53 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:11:53 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:11:53 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:11:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:11:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:11:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:11:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:11:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:11:53 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:11:53 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:11:53 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:11:53 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:13:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:13:02 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:13:02 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:13:02 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:13:02 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:13:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:13:06 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:13:06 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:13:06 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:13:06 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:13:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:13:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:13:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:13:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:13:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:13:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:13:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:13:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:13:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:13:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:13:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:13:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:13:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:13:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:13:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:13:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:13:08 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:13:08 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:13:08 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:13:08 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:13:08 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:13:08 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:13:08 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:13:08 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:13:08 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:13:08 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:13:08 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:13:08 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:14:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:14:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:14:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:14:04 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:14:04 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:14:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:14:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:14:04 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:14:04 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:14:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:14:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:14:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:14:04 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:14:04 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:14:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:14:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:14:04 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:14:04 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:14:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:14:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:14:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:14:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:14:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:14:05 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:14:05 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:14:05 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:14:05 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:15:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:15:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:15:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:15:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:15:51 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:15:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:15:51 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:15:51 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:15:51 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:15:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:15:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:15:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:15:51 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:15:51 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:15:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:15:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:15:51 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:15:51 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:15:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:15:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:15:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:15:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:15:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:15:52 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:15:52 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:15:52 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:15:52 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:15:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:15:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:15:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:15:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:15:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:15:53 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:15:53 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:15:53 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:15:53 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:15:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:15:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:15:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:15:53 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:15:53 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:15:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:15:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:15:53 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:15:53 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:17:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:17:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:17:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:17:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:17:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:17:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:17:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:17:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:17:57 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:17:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:17:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:17:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:17:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:17:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:17:58 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:17:58 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:17:58 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:17:58 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:19:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:19:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:19:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:19:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:19:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:19:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:19:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:19:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:19:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:19:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:19:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:19:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:20:24 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:20:24 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:20:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:20:24 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:20:24 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:20:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:20:25 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:20:25 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:20:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:20:25 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:20:25 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:20:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:20:25 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:20:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:20:25 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:20:25 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:20:25 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:20:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:20:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:20:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:20:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:20:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:20:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:20:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:20:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:20:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:20:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:20:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:20:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:20:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:20:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:20:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:20:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:20:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:20:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:20:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:20:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:20:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:20:27 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:20:27 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:21:24 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:21:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:21:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:21:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:21:25 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:21:25 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:21:25 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:21:25 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:21:25 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:21:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:21:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:21:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:21:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:21:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:21:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:21:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:21:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:21:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:21:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:21:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:21:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:21:27 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:21:27 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:21:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:21:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:21:27 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:21:27 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:23:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:23:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 15:23:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 10:23:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:23:06 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 15:23:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 15:23:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 10:23:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:23:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:23:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:23:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 15:23:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 15:23:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 15:23:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 15:23:07 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 10:23:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:23:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:07 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:23:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:23:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 10:23:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:23:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 15:23:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 15:23:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 10:23:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:23:08 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 10:23:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:23:08 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:08 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:08 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:08 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:23:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:23:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 15:23:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 15:23:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 10:23:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:23:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 10:23:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:23:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 10:23:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:23:09 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:09 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:09 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:09 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:23:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:23:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 15:23:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 15:23:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 15:23:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 15:23:15 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 10:23:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:23:15 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:15 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:15 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:15 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:23:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:23:20 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:20 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:20 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:20 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:23:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:23:23 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:23 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:23:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:23:23 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:23 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:23:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:26 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:23:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:23:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:23:28 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:28 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:23:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:23:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:23:28 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:23:28 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:25:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:25:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:25:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:25:27 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:25:27 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:25:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:25:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:25:28 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 15:25:28 --> 404 Page Not Found: Assets/fonts
ERROR - 2022-10-27 10:27:36 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:28:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:28:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:28:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:28:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:28:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:28:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:28:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:28:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:28:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:28:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:28:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:28:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:28:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:28:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:28:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:28:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:28:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:28:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:30:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:30:53 --> Severity: error --> Exception: syntax error, unexpected 'faces' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\sppd\application\views\backend\main.php 490
ERROR - 2022-10-27 10:30:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:30:54 --> Severity: error --> Exception: syntax error, unexpected 'faces' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\sppd\application\views\backend\main.php 490
ERROR - 2022-10-27 10:30:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:30:54 --> Severity: error --> Exception: syntax error, unexpected 'faces' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\sppd\application\views\backend\main.php 490
ERROR - 2022-10-27 10:30:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:30:54 --> Severity: error --> Exception: syntax error, unexpected 'faces' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\sppd\application\views\backend\main.php 490
ERROR - 2022-10-27 10:30:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:30:54 --> Severity: error --> Exception: syntax error, unexpected 'faces' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\sppd\application\views\backend\main.php 490
ERROR - 2022-10-27 10:30:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:30:54 --> Severity: error --> Exception: syntax error, unexpected 'faces' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\sppd\application\views\backend\main.php 490
ERROR - 2022-10-27 10:30:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:30:55 --> Severity: error --> Exception: syntax error, unexpected 'faces' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\sppd\application\views\backend\main.php 490
ERROR - 2022-10-27 10:30:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:30:55 --> Severity: error --> Exception: syntax error, unexpected 'faces' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\sppd\application\views\backend\main.php 490
ERROR - 2022-10-27 10:30:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:30:55 --> Severity: error --> Exception: syntax error, unexpected 'faces' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\sppd\application\views\backend\main.php 490
ERROR - 2022-10-27 10:31:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:31:47 --> Severity: error --> Exception: syntax error, unexpected 'faces' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\sppd\application\views\backend\main.php 510
ERROR - 2022-10-27 10:31:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:31:47 --> Severity: error --> Exception: syntax error, unexpected 'faces' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\sppd\application\views\backend\main.php 510
ERROR - 2022-10-27 10:32:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:32:06 --> Severity: error --> Exception: syntax error, unexpected 'faces' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\sppd\application\views\backend\main.php 1052
ERROR - 2022-10-27 10:32:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:32:07 --> Severity: error --> Exception: syntax error, unexpected 'faces' (T_STRING), expecting ',' or ')' C:\xampp\htdocs\sppd\application\views\backend\main.php 1052
ERROR - 2022-10-27 10:33:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:33:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:33:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:33:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:33:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:33:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:33:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:33:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:33:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:35:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:35:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:35:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:35:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:35:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:35:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:35:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:35:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:35:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:35:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:35:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:35:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:35:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:35:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:35:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:35:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:35:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:35:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:35:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:35:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:35:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:35:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:35:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:35:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:35:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:35:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:35:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:35:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:35:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:35:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:35:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:35:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:35:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:35:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:35:14 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:35:14 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:35:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:35:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:35:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:35:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:35:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:35:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:35:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:35:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:35:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:35:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:35:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:35:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:35:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:35:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:36:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:36:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:36:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:36:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:36:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:36:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:36:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:36:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:36:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:36:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:36:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:36:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:36:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:36:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:36:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:36:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:36:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:36:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:36:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:36:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:36:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:36:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:36:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:36:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:36:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:36:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:36:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:36:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:36:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:36:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:36:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:36:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:36:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:36:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:36:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:36:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:36:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:36:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:37:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:37:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:37:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:37:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:37:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:37:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:37:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:37:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:37:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:37:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:37:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:37:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:37:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:37:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:37:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:37:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:37:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:37:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:37:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:37:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:37:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:37:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:37:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:37:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:37:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:37:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:37:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:37:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:37:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:37:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:37:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:37:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:37:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:37:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:37:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:37:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:37:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:37:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:38:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:38:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:38:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:38:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:38:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:38:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:38:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:38:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:38:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:38:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:38:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:38:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:38:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:38:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:38:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:38:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:38:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:38:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:38:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:38:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:38:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:40:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:40:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:40:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:40:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:40:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:40:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:40:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:40:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:40:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:40:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:40:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:40:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:40:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:40:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:40:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:40:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:40:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:40:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:41:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:41:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:41:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:41:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:41:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:41:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:41:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:41:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:41:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:41:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:41:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:41:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:41:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:41:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:41:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:41:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:41:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:41:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:41:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:41:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:41:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:41:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:41:34 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:41:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:41:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:41:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:41:34 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:41:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:41:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:41:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:41:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:41:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:41:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:41:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:41:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:41:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:44:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:44:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:44:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:44:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:44:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:44:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:44:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:44:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:44:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:44:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:44:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:44:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:44:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:44:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:44:43 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:44:44 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:44:44 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:44:44 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:44:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:44:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:44:44 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:44:44 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:44:44 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:44:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:44:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:44:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:44:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:44:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:44:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:44:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:44:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:44:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:44:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:44:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:44:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:44:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:12 --> Severity: error --> Exception: Call to undefined function __sessiom() C:\xampp\htdocs\sppd\application\views\backend\main.php 43
ERROR - 2022-10-27 10:45:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:13 --> Severity: error --> Exception: Call to undefined function __sessiom() C:\xampp\htdocs\sppd\application\views\backend\main.php 43
ERROR - 2022-10-27 10:45:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:13 --> Severity: error --> Exception: Call to undefined function __sessiom() C:\xampp\htdocs\sppd\application\views\backend\main.php 43
ERROR - 2022-10-27 10:45:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:14 --> Severity: error --> Exception: Call to undefined function __sessiom() C:\xampp\htdocs\sppd\application\views\backend\main.php 43
ERROR - 2022-10-27 10:45:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:14 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:14 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:19 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:19 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:19 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:19 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:20 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:20 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:20 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:20 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:33 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:45:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:45:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:45:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:45:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:47:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:47:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:47:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:47:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:47:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:47:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:47:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:47:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:47:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:47:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:47:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:48:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:48:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:48:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:48:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:48:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:48:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:48:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:48:14 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:48:14 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:48:14 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:48:14 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:48:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:48:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:48:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:48:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:48:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:48:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:48:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:48:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:48:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:48:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:48:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:48:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:48:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:48:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:48:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:48:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:48:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:48:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:48:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:48:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:48:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:48:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:48:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:48:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:48:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:48:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:48:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:48:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:48:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:49:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:49:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:49:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:49:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:49:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:49:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:49:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:49:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:49:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:49:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:51:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:51:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:51:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:51:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:51:45 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:51:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:51:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:51:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:51:45 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:51:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:51:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:51:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:51:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:51:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:51:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:51:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:51:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:51:46 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:51:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:51:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:51:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:51:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:51:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:51:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:51:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:51:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:51:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:53:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:53:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:53:27 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-27 10:53:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:53:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:53:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:53:27 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:53:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:53:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:53:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:53:27 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:53:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:53:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:53:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:53:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:53:37 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:53:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:53:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:53:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:53:37 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:53:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:53:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:53:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:53:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:53:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:53:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:53:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:53:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:53:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:53:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:53:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:53:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:53:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:53:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:53:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:53:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:53:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:53:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:53:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:53:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:53:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:53:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:53:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:53:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:53:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:53:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:53:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:53:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:53:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:53:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:53:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:53:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:53:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:53:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:53:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:53:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:54:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:54:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:54:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:54:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:54:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:54:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:54:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:54:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:54:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:54:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:54:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:54:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:54:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:54:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:54:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:54:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:54:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:54:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:54:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:54:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:54:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:54:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:54:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:54:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:54:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:54:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:54:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:54:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:54:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:54:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:54:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:54:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:54:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:54:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:54:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:54:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:54:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:54:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:54:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:54:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:54:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:54:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:54:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:54:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:54:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:54:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:54:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:54:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:55:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:55:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:55:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:55:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:55:43 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:55:43 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:55:43 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:55:43 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:55:43 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:56:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:56:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:56:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:56:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:56:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:56:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:56:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:56:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:56:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:56:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:56:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:56:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:56:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:56:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:56:30 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:56:30 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:56:30 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:56:30 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:56:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:56:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:56:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:56:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:56:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:56:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:56:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:56:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:56:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:56:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:56:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:56:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:56:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:56:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:56:52 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:56:52 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:56:52 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:56:52 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:57:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:57:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:57:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:57:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:57:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:57:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:57:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:57:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:57:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:57:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:57:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:57:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:42 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:57:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:57:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:57:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:57:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:57:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:57:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:57:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:57:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:57:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:57:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:57:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:57:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:57:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:48 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:57:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:48 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:57:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:57:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:57:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:57:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:57:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:57:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:57:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:57:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:57:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:57:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:57:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:57:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:07 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:07 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:07 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:07 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:13 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:13 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:14 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:14 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:14 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:14 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:19 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:19 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:19 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:19 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:19 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:19 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:19 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:19 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:19 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:19 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:58:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:58:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:58:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:58:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:59:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:59:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:59:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:59:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:59:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:59:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:59:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:59:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:59:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:59:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:59:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:59:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:59:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:59:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:59:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:59:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:59:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:59:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:59:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:59:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:59:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:59:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:59:40 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:59:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:59:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:59:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:59:40 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:59:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:59:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:59:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:59:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:59:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:59:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:59:41 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:59:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:59:41 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:59:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:59:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:59:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:59:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:59:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:59:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:59:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:59:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:59:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:59:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:59:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:59:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:59:52 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:59:52 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 10:59:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 10:59:52 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 15:59:52 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 15:59:52 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:00:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:00:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:00:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:00:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:00:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:00:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:00:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:00:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:00:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:00:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:00:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:00:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:00:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:00:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:00:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:00:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:00:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:00:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:00:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:00:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:00:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:00:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:00:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:00:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:00:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:00:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:00:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:00:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:00:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:00:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:00:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:00:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:00:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:00:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:00:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:00:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:00:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:00:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:00:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:00:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:00:32 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:00:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:00:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:00:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:00:32 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:00:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:00:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:00:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:00:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:00:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:00:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:00:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:00:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:00:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:01:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:01:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:01:14 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:15 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:01:15 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:15 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:15 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:15 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:01:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:01:16 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:16 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:01:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:01:16 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:16 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:01:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:01:16 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:16 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:01:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:01:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:01:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:21 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:01:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:21 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:01:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:01:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:01:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:01:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:01:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:01:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:01:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:01:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:01:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:01:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:01:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:01:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:01:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:01:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:01:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:01:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:01:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:01:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:01:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:01:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:11:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:11:08 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-27 16:11:09 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-27 16:11:09 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-27 16:11:09 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-27 16:11:09 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-27 11:11:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:11:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:11:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:11:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:11:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:11:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:11:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:11:10 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-27 16:11:10 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-27 16:11:10 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-27 16:11:10 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-27 16:11:10 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-27 11:11:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:11:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:11:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:11:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:11:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:11:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:11:11 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-27 16:11:11 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-27 16:11:11 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-27 16:11:11 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-27 16:11:11 --> 404 Page Not Found: Assets/images
ERROR - 2022-10-27 11:11:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:11:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:11:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:11:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:11:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:11:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:11:46 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:11:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:11:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:11:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:11:47 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:11:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:11:47 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:13:07 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:13:07 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:07 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:13:07 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:13:07 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:13:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:13:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:13:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:13:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:13:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:13:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:13:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:13:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:13:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:13:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:13:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:13:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:13:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:13:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:13:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:13:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:13:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:13:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:13:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:13:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:13:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:13:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:13:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:13:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:13:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:13:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:13:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:13:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:13:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:13:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:13:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:13:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:13:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:13:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:13:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:13:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:13:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:13:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:13:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:13:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:13:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:13:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:13:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:13:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:13:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:13:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:13:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:13:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:13:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:13:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:14:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:14:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:14:09 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 11:14:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:14:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:14:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:14:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:14:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:14:09 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:14:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:14:09 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:14:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:14:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:14:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:14:10 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 11:14:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:14:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:14:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:14:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:14:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:14:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:14:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:14:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:14:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:14:11 --> 404 Page Not Found: Assets/js
ERROR - 2022-10-27 11:14:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:14:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:14:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:14:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:14:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:14:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:14:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:14:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:14:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:14:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:14:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:14:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:14:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:14:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:14:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:14:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:14:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:14:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:14:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:14:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:14:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:14:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:14:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:14:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:14:19 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:14:19 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:14:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:14:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:14:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:14:19 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:14:19 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:14:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:14:19 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:14:19 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:14:19 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:15:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:15:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:15:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:15:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:15:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:15:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:15:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:15:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:15:49 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:15:49 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:15:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:15:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:15:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:15:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:15:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:15:50 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:15:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:15:50 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:15:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:15:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:15:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:15:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:15:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:15:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:15:51 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:15:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:15:51 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:16:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:16:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:16:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:16:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:16:28 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:16:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:16:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:16:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:16:28 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:16:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:16:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:16:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:16:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:16:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:16:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:16:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:16:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:16:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:16:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:16:42 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:17:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:17:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:17:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:17:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:17:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:17:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:17:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:17:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:17:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:17:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:18:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:18:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:18:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:18:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:18:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:18:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:18:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:18:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:18:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:18:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:18:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:18:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:18:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:18:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:18:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:18:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:18:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:18:30 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:18:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:18:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:18:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:18:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:18:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:18:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:18:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:18:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:18:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:18:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:18:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:18:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:18:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:18:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:18:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:18:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:18:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:18:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:19:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:19:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:19:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:19:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:19:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:19:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:19:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:19:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:19:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:19:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:19:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:19:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:19:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:19:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:19:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:19:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:19:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:19:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:19:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:19:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:19:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:19:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:19:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:19:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:19:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:19:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:19:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:19:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:19:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:19:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:19:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:19:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:19:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:19:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:19:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:19:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:20:16 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:20:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:20:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:20:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:20:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:20:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:20:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:20:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:20:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:21:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:21:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:21:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:21:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:21:06 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:21:06 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:21:06 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:21:06 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:21:06 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:21:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:21:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:21:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:21:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:21:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:21:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:21:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:21:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:21:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:28:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:28:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:28:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:28:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:28:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:28:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:29:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:29:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:29:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:29:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:29:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:29:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:29:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:29:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:29:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:29:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:29:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:29:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:29:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:29:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:29:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:29:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:29:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:29:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:29:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:29:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:29:01 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:29:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:29:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:29:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:29:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:29:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:29:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:29:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:29:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:29:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:29:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:29:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:29:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:29:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:29:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:29:57 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:29:57 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:29:57 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:29:57 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:30:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:30:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:30:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:30:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:30:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:30:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:30:17 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:30:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:30:17 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:30:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:30:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:30:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:30:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:30:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:30:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:30:18 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:30:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:30:18 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:30:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:30:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:30:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:30:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:30:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:30:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:30:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:30:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:30:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:31:01 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:31:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:31:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:31:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:02 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:31:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:31:02 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:31:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:31:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:31:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:31:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:31:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:31:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:31:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:31:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:31:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:31:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:31:04 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:31:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:31:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:31:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:31:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:53 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:31:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:31:53 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:31:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:31:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:31:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:31:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:54 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:31:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:31:54 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:31:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:55 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:31:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:31:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:31:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:31:55 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:31:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:31:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:31:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:31:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:31:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:31:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:31:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:31:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:31:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:31:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:56 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:31:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:31:56 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:31:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:31:57 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:31:57 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:31:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:57 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:31:57 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:31:57 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:31:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:31:58 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:31:58 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:31:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:31:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:31:58 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:31:58 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:32:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:32:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:32:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:32:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:10 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:32:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:32:10 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:32:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:32:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:32:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:32:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:32:11 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:32:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:32:11 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:32:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:32:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:32:12 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:32:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:32:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:32:12 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:32:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:30 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:32:30 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:32:30 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:32:30 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:32:30 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:32:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:32:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:32:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:32:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:32:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:32:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:31 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:32:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:32:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:32:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:32:31 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:32:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:38 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:32:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:32:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:32:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:32:38 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:32:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:32:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:32:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:32:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:32:39 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:32:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:32:39 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:34:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:34:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:34:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:34:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:34:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:34:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:34:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:34:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:34:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:39:20 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:39:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:39:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:39:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:39:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:39:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:39:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:39:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:39:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:39:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:39:58 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:39:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:39:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:39:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:39:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:39:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:39:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:39:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:39:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:39:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:39:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:39:59 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:39:59 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:40:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:40:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:40:00 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:40:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:40:00 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:40:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:40:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:40:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:40:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:40:03 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:40:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:40:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:40:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:40:03 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:40:04 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:40:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:40:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:40:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:40:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:40:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:40:05 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:40:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:40:05 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:40:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:40:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:40:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:40:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:40:08 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:40:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:40:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:40:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:40:08 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:40:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:40:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:40:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:40:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:40:22 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:40:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:40:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:40:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:40:22 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:40:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:40:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:40:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:40:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:40:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:40:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:40:23 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:40:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:40:23 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:40:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:40:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:40:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:40:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:40:29 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 16:40:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:40:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:40:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 16:40:29 --> 404 Page Not Found: Fonts/Rubik
ERROR - 2022-10-27 11:53:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
ERROR - 2022-10-27 11:53:33 --> Could not find the specified $config['composer_autoload'] path: vendor/autoload.php
